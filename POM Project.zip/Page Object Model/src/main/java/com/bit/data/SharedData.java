package com.bit.data;

public class SharedData {
	
	public static String targetUrl = "http://www.target.com";
	public static String homePageTitle ="Target : Expect More. Pay Less.";
	public static String registryPageTitle = "Gift Registry & Lists : Target";
	
	
	
	
	
	
}
